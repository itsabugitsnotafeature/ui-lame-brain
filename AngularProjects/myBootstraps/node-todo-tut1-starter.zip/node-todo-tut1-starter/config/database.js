module.exports = {

	// the database url to connect
	url : 'mongodb://node:nodeuser@mongo.onmodulus.net:27017/uwO3mypu'
}
