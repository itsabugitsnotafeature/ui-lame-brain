TODO before release
---

* implement filters (using routing or another method)
* build javascript using cram.js
