AngularJS version of Bootstrap's collapse plugin.
Provides a simple way to hide and show an element with a css transition
