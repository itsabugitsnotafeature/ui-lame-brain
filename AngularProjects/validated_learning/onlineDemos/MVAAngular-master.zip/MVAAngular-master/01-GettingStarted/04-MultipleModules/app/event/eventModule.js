

(function(){

	angular.module('eventModule', [])
	.config([function () {
		console.log("Event Module:: config");
	}])
	.run([function () {
		console.log("Events Module::running");
	}])

})();