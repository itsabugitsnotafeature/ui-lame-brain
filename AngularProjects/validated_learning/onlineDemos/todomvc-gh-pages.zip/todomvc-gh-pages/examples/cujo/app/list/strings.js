/*global define */
define({
	markAll: 'Mark all as complete'
});
