/*global $ */
/*jshint unused:false */
var app = app || {};
var ENTER_KEY = 13;
var ESCAPE_KEY = 27;

document.addEventListener('DOMContentLoaded', function () {
	'use strict';

	// kick things off by creating the `App`
	new app.AppView();
}, false);
